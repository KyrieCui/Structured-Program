import java.io.Serializable;

public class ControllerHistory extends Controller implements Serializable {
	public ControllerHistory(ElectricityCompany m) {
		super(m);
	}
}
