import java.io.Serializable;

public interface ModelListener extends Serializable {
	public void update();
}
