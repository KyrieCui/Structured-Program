import java.io.Serializable;

public class ControllerSimple extends Controller implements Serializable{
	//private ElectricityCompany m;
	public ControllerSimple(ElectricityCompany m) {
		super(m);
	}
}
