
public class ControllerHistory extends Controller {
	public ControllerHistory(ElectricityCompany m) {
		super(m);
	}
}
