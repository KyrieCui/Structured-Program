
public class ControllerSimple {
	private ElectricityCompany m;
	public ControllerSimple(ElectricityCompany m) {
		this.m=m;
	}
}
