
public interface Consumer {
	public String getName();
	public int getPower();
	public void morePower(int amount);
}
