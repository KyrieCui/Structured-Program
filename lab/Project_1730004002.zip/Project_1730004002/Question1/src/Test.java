
public class Test {
	public static void main(String[] agrs) {
		Building.testBuilding();
	}
}
