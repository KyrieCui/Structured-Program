
public interface ModelListener {
	public void update();
}
