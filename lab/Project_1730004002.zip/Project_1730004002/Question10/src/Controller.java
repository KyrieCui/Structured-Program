
public class Controller {
	protected ElectricityCompany m;
	public Controller(ElectricityCompany m) {
		this.m=m;
	}
}
