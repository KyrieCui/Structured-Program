
public class ControllerSimple extends Controller {
	//private ElectricityCompany m;
	public ControllerSimple(ElectricityCompany m) {
		super(m);
	}
}
