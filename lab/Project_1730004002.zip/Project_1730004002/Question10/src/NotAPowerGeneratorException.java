
public class NotAPowerGeneratorException extends Exception {
	public NotAPowerGeneratorException(String msg){
		super(msg);
	}
}
