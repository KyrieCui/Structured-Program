
public class UnknownConsumerException extends Exception {
	public UnknownConsumerException(String msg) {
		super(msg);
	}
}
