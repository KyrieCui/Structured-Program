#include<stdio.h>
int Power2(int n);//the subfunction declaration