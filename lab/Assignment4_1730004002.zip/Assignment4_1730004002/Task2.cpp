/*includes two functions. The main function reads the sequence of
integers (assume ends with -1), a sub-function will find the biggest integer and lowest
integer. The main function will call the sub-function, pass the integers to it through
parameters and print the biggest integer and lowest integer*/
#include <stdio.h>
void subfunction(int n,int a[],int*max,int*min);//function prototype
int main()
{
	int a[20];
	int n,i,max,min;
	printf("Please enter how many integers you want to input(the number of integers don not more than 20): ");
	scanf("%d",&n);//enter a number
	printf("Please enter a sequence of integers: ");
	for(i=0;i<n;i++)
		scanf("%d",&a[i]);//enter the sequence of integers
	subfunction(n,a,&max,&min);//call the function
	printf("The maximun is %d \n",max);
	printf("The minimun is %d\n",min);//print out the result
	return 0;
}
void subfunction(int n,int a[],int*max,int*min)
{
	*max=*a;
	*min=*a;//initialize the poiter
	int *p;
	for(p=a+1;p<a+n;p++){
		if(*p>*max){
			*max=*p;
		}
		else if(*p<*min){
			*min=*p;
		}
	}
	;
}
	
	
		



