/*Input a sequence of data and save it in the array. Then set up a pointer to point to the first
data of the array, output the data in array one by one by moving the pointer. Please also
output the address of each data in array*/
#include <stdio.h>
int main()
{
	int a[20];
	int n,i;
	int *p;//declare a pointer
	p=a;//the pointer point to the address of array
	printf("Please enter how many integers you want to input(the number of integers don not more than 20): ");
	scanf("%d",&n);//enter a number
	printf("Please %d integers\n",n);//enter a sequence of data
	for(i=0;i<n;i++){
		scanf("%d",&a[i]);
	printf("The data is:%d, the address is:%x.\n",*p++,p);//print out the data and address
}
	return 0;
}
