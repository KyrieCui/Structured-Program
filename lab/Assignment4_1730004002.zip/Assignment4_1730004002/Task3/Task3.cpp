/*Write a program to read students�� names and scores from a file student.txt. Then sort them according to scores in descending order and 
save the sorted data in another file sorted.txt.*/
#include<stdio.h>
struct student{
		char name[10];
		int score;
	};
	struct student stu[10];
void sort(struct student *a);//function prototype
int main()
{   
	int i;
	struct student *p;//declare a pointer
	p=stu;
	FILE *fp;
	fp=fopen("student.txt","r");//read a file
	for(i=0;i<10;i++)
	fscanf(fp,"%s %d",stu[i].name,&stu[i].score);//scanf the file to the struct
	fclose(fp);//close the file
	sort(p);//function call
	return 0;
}
void sort(struct student *a)
{
	int i,j;
	FILE*fp2;
	struct student temp;
	for(i=0;i<9;i++){           //start to sort
		for(j=0;j<9-i;j++){
	if((a+j)->score<(a+j+1)->score){
				temp=*(a+j);
				*(a+j)=*(a+j+1);
				*(a+j+1)=temp;
	}
}
}
	//finish sorting
	fp2=fopen("sorted.txt","w+");//creat a new file 
	for(i=0;i<10;i++){
	fprintf(fp2,"%s %d\n",(a+i)->name,(a+i)->score);//put data in the new file

	}
	fclose(fp2);//close the file
		
}