/* Compare the out put of two programs*/
#include<stdio.h>
int main()
{
	printf("This is the first program output:\n"); 
	printf("Hello\n"); //the first program output
	
	printf("This is the second progtam ouput:\n");
	printf("Hello\n");//the second program output
	printf("World\n");
	return 0; 
}