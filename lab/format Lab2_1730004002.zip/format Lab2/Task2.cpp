/*print the Bytes for each type*/
#include <stdio.h>
int main()
{
	printf("Number of bytes used to store a char type variable is %u bytes.\n", sizeof(char)); //the bytes of char
	printf("Number of bytes used to store a short int type variable is %u bytes.\n", sizeof(short int)); //the bytes of short int
	printf("Number of bytes used to store an int type variable is %u bytes.\n", sizeof(int)); //the bytes of int
	printf("Number of bytes used to store a long int type variable is %u bytes.\n", sizeof(long int)); //the bytes of long int
	printf("Number of bytes used to store a float type variable is %u bytes.\n", sizeof(float)); // the bytes of float
	printf("Number of bytes used to store a double type variable is %u bytes.\n", sizeof(double)); // the bytes of double

	return 0;
}
