/* Task3*/
#include <stdio.h>
int main()
{
	float value1, value2, sum;
	value1= 50;
	value2= 25;
	sum= value1 + value2;
	printf("The sum of %.1f and %f is %f\n", value1,value2, sum);

	return 0;
}